/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Fib;

/**
 *
 * @author rj
 */
public class Fibonacci {
    public void generate_Fibonacci(int n)
    {
        int f0=0,f1=1,s;
        System.out.print("0 1 ");
        for(int i=0;i<=n-2;i++)
        {   
                s=f0+f1;   
                System.out.print(s+" ");
                f0=f1;
                f1=s;
        }    
    }        
    
}
