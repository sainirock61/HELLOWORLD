/*2
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p17;
import differentPackageClass.*;
import java.util.Scanner;

/**
 *
 * @author rj
 */
public class P17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          System.out.println("Program to show the difference between access specifiers..."); 
          Scanner inp=new Scanner(System.in);
          System.out.println("Enter your choice:\n1. Public function of this class.\n2. Private function of this class.\n3. Protected function of this class.\n4. Default function of this class.\n5. Public function of New class of same package.\n6. Private function of New class of same package.\n7. Protected function of New class of same package.\n8. Default function of New class of same package.\n9.Public function of DifferentPackageClass class of different package.\n10.Private function of DifferentPackageClass class of different package.\n11.Protected function of DifferentPackageClass class of different package.\n12.Default function of DifferentPackageClass class of different package.");
          int n=inp.nextInt();
          New cobj1=new New();
          DifferentPackageClass cobj2=new DifferentPackageClass();

          switch(n)
          {
              case 1:pubfunct();break;
              case 2:prifunct();break;
              case 3:profunct();break;
              case 4:defaultfunct();break;
              case 5:cobj1.pubfunct();break;
              case 6:System.out.println("Cannot access a private function of another class in the same package.");break; 
              case 7:cobj1.profunct();break;
              case 8:cobj1.defaultfunct();break; 
              case 9:cobj2.pubfunct();break;
              case 10:System.out.println("Cannot access a private function of another class in the different package.");break; 
              case 11:System.out.println("Cannot access a protected function of another class in the different package.");break;
              case 12:System.out.println("Cannot access a default function of another class in the different package.");break;  
          }    
        }

         public static void pubfunct()
         {
             System.out.println("Public function of this class.");
         }   
         private static void prifunct()
         {
            System.out.println("Private function of this class.");
         } 
         protected static void profunct()
         {
            System.out.println("Protected function of this class.");
         }
         static void defaultfunct()
         {
            System.out.println("Default function of this class.");   
         }
            
}

class New
{
    public static void pubfunct()
    {
        System.out.println("Public function of New class of same package.");
    }   
    private static void prifunct()
    {
        System.out.println("Private function of New class of same package.");
    } 
    protected static void profunct()
    {
        System.out.println("Protected function of New class of same package.");
    }   
    static  void defaultfunct()
    {
        System.out.println("Default function of New class of same package.");   
    }        
}        