/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package differentPackageClass;

/**
 *
 * @author rj
 */
public class DifferentPackageClass {
     public static void pubfunct()
    {
         System.out.println("Public function of DifferentPackageClass class of different package.");
     }   
     private static void prifunct()
    {
         System.out.println("Private function of DifferentPackageClass class of different package.");
    } 
    protected static void profunct()
    {
        System.out.println("Protected function of DifferentPackageClass class of different package.");
     } 
    static void defaultfunct()
    {
         System.out.println("Default function of DifferentPackageClass class of different package.");   
    }        
    
}
