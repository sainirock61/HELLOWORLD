/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p15;
import java.util.Scanner;

/**
 *
 * @author rj
 */
public class Input {
     protected String enterinput()
     {
         Scanner inp=new Scanner(System.in);
         System.out.println("Enter a line please:");
         String str=inp.nextLine();
         return str;
    }        
    
}
