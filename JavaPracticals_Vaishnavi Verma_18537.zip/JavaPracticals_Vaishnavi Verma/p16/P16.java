/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p16;
import java.util.Scanner;
import Fib.Fibonacci;

/**
 *
 * @author rj
 */
public class P16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fibonacci f=new Fibonacci();   
        System.out.println("A program to create a multilevel package and also creates a reusable class to generate Fibonacci series, where the function to generate Fibonacci Series is given in a different file belonging to the same package.");
        System.out.print("Enter a number to compute Fibonacci series till that number of terms:");
        Scanner inp=new Scanner(System.in);
        int n=inp.nextInt();
        System.out.print("Fibonacci Series till "+n+"th number of terms is:");
        if(n==0)
        System.out.println("0");
        if(n==1)
        System.out.println("0 1");
        if(n==2)
        System.out.println("0 1 1");
        if(n>2)
        f.generate_Fibonacci(n);    
        if(n<=0)
        System.out.print("Invalid Entry!");
       }
    
}
